# Server - Agora Conversational AI

This is the backend service that:
- Generates Agora RTC tokens (`POST /token`)
- Proxies chat messages to OpenAI (`POST /chat`)
- Returns conversation history (`GET /history/:sessionId`)

Setup (PowerShell):

```powershell
cd server
npm install
cp .env.example .env
# Edit .env to set OPENAI_API_KEY, AGORA_APP_ID and AGORA_APP_CERTIFICATE
npm run dev
```

Endpoints:
- `POST /token` body: { channelName, uid?, role?, expire? } -> returns { token, appID, channelName, uid }
- `POST /chat` body: { sessionId, message } -> returns { reply }
- `GET /history/:sessionId` -> returns { messages: [...] }

Security:
- Keep `AGORA_APP_CERTIFICATE` secret. In production, limit token expiry and authenticate requests to this server.

Notes:
- The server uses an in-memory Map for sessions (demo only). Swap out for a DB for persistence.
- The OpenAI usage is basic; consider streaming or function-calling if you need advanced behaviors.
