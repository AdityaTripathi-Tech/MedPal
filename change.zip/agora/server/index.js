require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fileUpload = require('express-fileupload');
const { RtcTokenBuilder, RtcRole } = require('agora-access-token');
const { OpenAI } = require('openai');

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));
app.use(fileUpload());

// Simple in-memory session store (for demo only)
const sessions = new Map();

// Initialize OpenAI client
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// In-memory memory storage (key: sessionId, value: array of memories)
const memoryStore = new Map();

// Emotion detection keywords
const emotionKeywords = {
  happy: ['happy', 'great', 'wonderful', 'awesome', 'love', 'enjoy', 'fantastic', 'excellent', 'amazing', 'beautiful'],
  sad: ['sad', 'unhappy', 'depressed', 'lonely', 'heartbroken', 'struggle', 'down', 'miserable', 'upset', 'devastated'],
  excited: ['excited', 'thrilled', 'pumped', "can't wait", 'amazing', 'fantastic', 'incredible', 'wonderful', 'thrilled', 'pumped'],
  angry: ['angry', 'furious', 'mad', 'frustrated', 'hate', 'irritated', 'annoyed', 'outraged', 'fuming', 'livid'],
  anxious: ['worried', 'nervous', 'scared', 'stressed', 'panic', 'overwhelmed', 'anxious', 'concerned', 'frightened', 'uneasy']
};

// Helper: detect emotion from text
function detectEmotion(text) {
  const lowerText = text.toLowerCase();
  for (const [emotion, keywords] of Object.entries(emotionKeywords)) {
    if (keywords.some(k => lowerText.includes(k))) {
      return emotion;
    }
  }
  return 'neutral';
}

// Helper: get or create session
function getSession(sessionId) {
  if (!sessions.has(sessionId)) {
    // Initialize with a brief system prompt
    sessions.set(sessionId, [
      { role: 'system', content: 'You are a helpful assistant for voice and text chat. Keep answers concise and friendly.' }
    ]);
  }
  return sessions.get(sessionId);
}

// Agora token endpoint
app.post('/token', (req, res) => {
  const appID = process.env.AGORA_APP_ID;
  const appCertificate = process.env.AGORA_APP_CERTIFICATE;
  const { channelName, uid = 0, role = 'publisher', expire = parseInt(process.env.AGORA_TOKEN_EXPIRE || '3600') } = req.body;

  if (!appID || !appCertificate) {
    return res.status(500).json({ error: 'AGORA_APP_ID or AGORA_APP_CERTIFICATE not set in server env' });
  }
  if (!channelName) return res.status(400).json({ error: 'channelName required' });

  const roleEnum = role === 'publisher' ? RtcRole.PUBLISHER : RtcRole.SUBSCRIBER;
  const currentTs = Math.floor(Date.now() / 1000);
  const privilegeExpiredTs = currentTs + expire;

  const token = RtcTokenBuilder.buildTokenWithUid(appID, appCertificate, channelName, uid, roleEnum, privilegeExpiredTs);
  res.json({ token, appID, channelName, uid });
});

// Chat endpoint: receives { sessionId, message }
app.post('/chat', async (req, res) => {
  try {
    const { sessionId = 'default', message } = req.body;
    if (!message) return res.status(400).json({ error: 'message required' });

    // Detect emotion from user message
    const emotion = detectEmotion(message);

    const session = getSession(sessionId);
    session.push({ role: 'user', content: message });

    // Build messages with a max context length (last 12 messages)
    const context = session.slice(-12);

    // Call OpenAI Chat Completions
    const response = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: context
    });

    const aiMessage = response.choices && response.choices[0] && response.choices[0].message ? response.choices[0].message.content : 'Sorry, I had an error.';

    session.push({ role: 'assistant', content: aiMessage });

    // Return emotion along with reply
    res.json({ reply: aiMessage, emotion });
  } catch (err) {
    console.error('Chat error', err);
    res.status(500).json({ error: err.message || String(err) });
  }
});

// Get session history
app.get('/history/:sessionId', (req, res) => {
  const sessionId = req.params.sessionId || 'default';
  const session = sessions.get(sessionId) || [];
  res.json({ messages: session });
});

// Prescription reader: upload image and extract medicine info
app.post('/prescription', async (req, res) => {
  try {
    const { imageBase64, sessionId = 'default' } = req.body;
    if (!imageBase64) return res.status(400).json({ error: 'imageBase64 required' });

    // Call OpenAI Vision API to analyze the prescription image
    const message = await openai.chat.completions.create({
      model: 'gpt-4-vision-preview', // or use 'gpt-4' with vision capability
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'image_url',
              image_url: {
                url: imageBase64 // Must be a data: URL or https: URL
              }
            },
            {
              type: 'text',
              text: 'Please analyze this medical prescription image and extract all medicine details. Return the data in JSON format with fields: patientName, date, doctor, medications (array with name, dosage, frequency, duration for each). If you cannot read parts, note them as "unclear".'
            }
          ]
        }
      ]
    });

    const responseText = message.choices[0].message.content;
    
    // Try to parse JSON from response
    let prescriptionData;
    try {
      // Extract JSON from response if it's wrapped in markdown code blocks
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      prescriptionData = jsonMatch ? JSON.parse(jsonMatch[0]) : { raw: responseText };
    } catch (e) {
      prescriptionData = { raw: responseText };
    }

    // Store in session if needed
    const session = getSession(sessionId);
    session.push({
      role: 'assistant',
      content: `Prescription analysis:\n${JSON.stringify(prescriptionData, null, 2)}`
    });

    res.json({ prescription: prescriptionData });
  } catch (err) {
    console.error('Prescription error', err);
    res.status(500).json({ error: err.message || String(err) });
  }
});

// ========== MEMORY ENDPOINTS ==========

// POST /memory - Save a memory
app.post('/memory', (req, res) => {
  try {
    const { sessionId = 'default', content, emotion } = req.body;
    if (!content) return res.status(400).json({ error: 'content required' });

    // Initialize memory array for session if doesn't exist
    if (!memoryStore.has(sessionId)) {
      memoryStore.set(sessionId, []);
    }

    // Create memory object
    const memory = {
      id: Date.now(),
      sessionId,
      content,
      emotion: emotion || detectEmotion(content),
      timestamp: new Date().toISOString(),
      isFavorite: false
    };

    // Add to memory store
    memoryStore.get(sessionId).push(memory);

    res.json(memory);
  } catch (err) {
    console.error('Memory save error', err);
    res.status(500).json({ error: err.message || String(err) });
  }
});

// GET /memories/:sessionId - Get all memories for a session
app.get('/memories/:sessionId', (req, res) => {
  try {
    const sessionId = req.params.sessionId;
    const memories = memoryStore.get(sessionId) || [];
    res.json(memories);
  } catch (err) {
    console.error('Memory retrieve error', err);
    res.status(500).json({ error: err.message || String(err) });
  }
});

// PUT /memory/:memoryId/favorite - Toggle favorite status
app.put('/memory/:memoryId/favorite', (req, res) => {
  try {
    const { memoryId } = req.params;
    const { sessionId = 'default' } = req.body;
    const memoryIdNum = parseInt(memoryId, 10);

    const memories = memoryStore.get(sessionId) || [];
    const memory = memories.find(m => m.id === memoryIdNum);

    if (!memory) {
      return res.status(404).json({ error: 'Memory not found' });
    }

    memory.isFavorite = !memory.isFavorite;
    res.json(memory);
  } catch (err) {
    console.error('Memory favorite error', err);
    res.status(500).json({ error: err.message || String(err) });
  }
});

// DELETE /memory/:memoryId - Delete a memory
app.delete('/memory/:memoryId', (req, res) => {
  try {
    const { memoryId } = req.params;
    const { sessionId = 'default' } = req.body;
    const memoryIdNum = parseInt(memoryId, 10);

    const memories = memoryStore.get(sessionId) || [];
    const index = memories.findIndex(m => m.id === memoryIdNum);

    if (index === -1) {
      return res.status(404).json({ error: 'Memory not found' });
    }

    const deleted = memories.splice(index, 1);
    res.json({ success: true, deleted: deleted[0] });
  } catch (err) {
    console.error('Memory delete error', err);
    res.status(500).json({ error: err.message || String(err) });
  }
});

app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
