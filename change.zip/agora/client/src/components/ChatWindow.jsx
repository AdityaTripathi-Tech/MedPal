import React, { useEffect, useState, useRef } from 'react'
import axios from 'axios'

// Use Python Flask backend on port 3001 (lightweight server)
const SERVER_ORIGIN = 'http://localhost:3001'

export default function ChatWindow() {
  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const [sessionId] = useState(() => 'session-' + Math.random().toString(36).slice(2, 9))
  const [isRecording, setIsRecording] = useState(false)
  const [inCall, setInCall] = useState(false)
  const [muted, setMuted] = useState(false)
  const [uploadedImage, setUploadedImage] = useState(null)
  const mediaStreamRef = useRef(null)
  
  // NEW: Memory and mood state
  const [memories, setMemories] = useState([])
  const [currentMood, setCurrentMood] = useState('neutral')
  const [showMemories, setShowMemories] = useState(false)
  const [messageEmotions, setMessageEmotions] = useState({}) // Track emotion for each message
  const [authUser, setAuthUser] = useState('')
  const [authPass, setAuthPass] = useState('')

  useEffect(() => {
    // Load memories for this session
    loadMemories()
  }, [sessionId])

  // Poll health endpoint and update indicator
  useEffect(() => {
    let mounted = true
    const check = async () => {
      try {
        const res = await axios.get(`${SERVER_ORIGIN}/health`)
        if (!mounted) return
        const el = document.getElementById('reactHealth')
        if (el) el.textContent = res.data?.status === 'healthy' ? 'Healthy' : 'Unhealthy'
      } catch (e) {
        const el = document.getElementById('reactHealth')
        if (el) el.textContent = 'Offline'
      }
    }
    check()
    const id = setInterval(check, 10000)
    return () => { mounted = false; clearInterval(id) }
  }, [])

  // Apply axios default auth header when credentials are saved
  useEffect(() => {
    if (authUser && authPass) {
      const pair = btoa(`${authUser}:${authPass}`)
      axios.defaults.headers.common['Authorization'] = `Basic ${pair}`
    } else {
      delete axios.defaults.headers.common['Authorization']
    }
  }, [authUser, authPass])

  // Load saved credentials from sessionStorage on mount
  useEffect(() => {
    try {
      const su = sessionStorage.getItem('agora_auth_user')
      const sp = sessionStorage.getItem('agora_auth_pass')
      if (su) setAuthUser(su)
      if (sp) setAuthPass(sp)
    } catch (e) {
      // ignore
    }
  }, [])

  // NEW: Load memories from backend
  const loadMemories = async () => {
    try {
      const res = await axios.get(`${SERVER_ORIGIN}/memories?sessionId=${encodeURIComponent(sessionId)}`)
      setMemories(res.data.memories || [])
    } catch (err) {
      console.warn('Could not load memories', err)
    }
  }

  // NEW: Save a memory
  const saveMemory = async (content, emotion) => {
    try {
      const res = await axios.post(`${SERVER_ORIGIN}/memory`, {
        sessionId,
        message: content,
        emotion
      })
      // server returns { success: True, memory: { ... } }
      const memory = res.data.memory || res.data
      setMemories(prev => [...prev, memory])
      setMessages(prev => [...prev, { role: 'system', content: `💾 Memory saved: "${content}"` }])
      return memory
    } catch (err) {
      console.warn('Could not save memory', err)
      return null
    }
  }

  // NEW: Toggle favorite memory
  const toggleFavorite = async (memoryId) => {
    try {
      const res = await axios.put(`${SERVER_ORIGIN}/memory/${memoryId}/favorite`, {
        sessionId
      })
      setMemories(prev => prev.map(m => m.id === memoryId ? res.data : m))
    } catch (err) {
      console.warn('Could not update memory', err)
    }
  }

  // NEW: Delete memory
  const deleteMemory = async (memoryId) => {
    try {
      await axios.delete(`${SERVER_ORIGIN}/memory/${memoryId}`, {
        data: { sessionId }
      })
      setMemories(prev => prev.filter(m => m.id !== memoryId))
    } catch (err) {
      console.warn('Could not delete memory', err)
    }
  }

  // NEW: Reminder scheduling (client-side demo)
  const [reminders, setReminders] = useState({}) // memoryId -> timeoutId

  const scheduleReminder = async (memory) => {
    // Ask user for minutes until reminder
    const minutesStr = prompt('Set reminder in how many minutes? (e.g. 10)', '10')
    if (!minutesStr) return
    const minutes = parseFloat(minutesStr)
    if (isNaN(minutes) || minutes <= 0) {
      alert('Please enter a valid number of minutes.')
      return
    }

    const ms = Math.max(1000, Math.round(minutes * 60 * 1000))

    // Request notification permission
    if (window.Notification && Notification.permission !== 'granted') {
      try { await Notification.requestPermission() } catch (e) { /* ignore */ }
    }

    const timeoutId = setTimeout(() => {
      const title = 'Memory Reminder'
      const body = `${memory.content.substring(0, 120)}`
      if (window.Notification && Notification.permission === 'granted') {
        new Notification(title, { body })
      } else {
        alert(`⏰ Reminder: ${body}`)
      }
      // remove reminder
      setReminders(prev => { const copy = { ...prev }; delete copy[memory.id]; return copy })
    }, ms)

    setReminders(prev => ({ ...prev, [memory.id]: timeoutId }))
    setMessages(prev => [...prev, { role: 'system', content: `⏰ Reminder set for memory: "${memory.content.substring(0,40)}..." in ${minutes} minute(s).` }])
  }

  const cancelReminder = (memoryId) => {
    const timeoutId = reminders[memoryId]
    if (timeoutId) {
      clearTimeout(timeoutId)
      setReminders(prev => { const copy = { ...prev }; delete copy[memoryId]; return copy })
      setMessages(prev => [...prev, { role: 'system', content: `⏹️ Reminder canceled for memory ${memoryId}` }])
    }
  }

  const sendMessage = async (text) => {
    if (!text) return
    const userMsg = { role: 'user', content: text }
    setMessages(prev => [...prev, userMsg])
    setInput('')

    // Check for memory commands
    const lowerText = text.toLowerCase()
    
    // Handle "save memory" or "remember"
    if (lowerText.includes('save') && lowerText.includes('memory')) {
      await saveMemory(text, 'neutral')
      return
    }
    
    // Handle "show memories" or "tell my story"
    if (lowerText.includes('memory') || lowerText.includes('story')) {
      const favoriteMemories = memories.filter(m => m.isFavorite)
      if (favoriteMemories.length === 0) {
        setMessages(prev => [...prev, { role: 'system', content: '📖 No memories saved yet. Try "Save this memory" to start recording moments!' }])
      } else {
        let story = '📖 YOUR STORY\n━━━━━━━━━━━━\n\n'
        const byEmotion = {}
        memories.forEach(m => {
          if (!byEmotion[m.emotion]) byEmotion[m.emotion] = []
          byEmotion[m.emotion].push(m)
        })
        for (const [emotion, mems] of Object.entries(byEmotion)) {
          story += `${emotion}:\n`
          mems.forEach(m => story += `  • ${m.content}\n`)
        }
        setMessages(prev => [...prev, { role: 'system', content: story }])
      }
      return
    }

    try {
      const res = await axios.post(`${SERVER_ORIGIN}/chat`, { sessionId, message: text })
      const reply = res.data.reply
      const emotion = res.data.emotion || 'neutral'
      
      // Update current mood
      if (emotion && emotion !== 'neutral') {
        setCurrentMood(emotion)
      }
      
      // Track emotion for this message
      setMessageEmotions(prev => ({ ...prev, [messages.length]: emotion }))
      
      // Add message with emotion info
      // Humanize reply slightly for warmer tone if backend reply seems generic
      const humanized = humanizeReply(reply, emotion)
      const assistantMsg = { role: 'assistant', content: humanized, emotion }
      setMessages(prev => [...prev, assistantMsg])

      // Optional TTS using browser speechSynthesis
      if ('speechSynthesis' in window) {
        const utter = new SpeechSynthesisUtterance(reply)
        utter.lang = 'en-US'
        utter.rate = 1
        window.speechSynthesis.speak(utter)
      }
      
      // Auto-save memory if emotion detected
      if (emotion !== 'neutral' && lowerText.length > 20) {
        await saveMemory(text, emotion)
      }
    } catch (err) {
      setMessages(prev => [...prev, { role: 'assistant', content: 'Error: could not reach server.' }])
    }
  }

  // Small client-side humanization helper to make replies sound friendlier
  const humanizeReply = (text, emotion) => {
    if (!text || text.length < 10) return text
    // Append empathetic sentence based on emotion if not already present
    const endings = {
      happy: "I'm really glad to hear that — it warms my circuits!",
      sad: "I'm sorry you're feeling that way. I'm here to listen whenever you need.",
      angry: "That sounds frustrating. Take a breath — I'm with you.",
      excited: "Wow — that's exciting! Tell me more!",
      anxious: "You're not alone in this. Let's take it one step at a time.",
      loving: "That's beautiful. Love really lights up life.",
      grateful: "Gratitude is wonderful — I'm glad you feel that way.",
      surprised: "That's surprising — how do you feel about it?",
      confident: "I love your confidence. Keep it up!",
      peaceful: "That calm sounds lovely. Hold on to it."
    }

    const ending = endings[emotion]
    if (ending && !text.includes(ending)) {
      // Keep final reply length reasonable
      return text.trim() + ' ' + ending
    }
    return text
  }

  const handleSend = (e) => {
    e.preventDefault()
    sendMessage(input)
  }

  // Basic STT via Web Speech API (if available)
  let recognition = null
  if (typeof window !== 'undefined' && window.SpeechRecognition) {
    recognition = new window.SpeechRecognition()
  } else if (typeof window !== 'undefined' && window.webkitSpeechRecognition) {
    recognition = new window.webkitSpeechRecognition()
  }

  const toggleRecording = () => {
    if (!recognition) {
      alert('SpeechRecognition not available in this browser.');
      return;
    }
    if (!isRecording) {
      recognition.lang = 'en-US'
      recognition.interimResults = false
      recognition.onresult = (e) => {
        const text = Array.from(e.results).map(r => r[0].transcript).join('\n')
        setInput(prev => prev ? prev + ' ' + text : text)
        // Auto-send after STT result
        sendMessage(text)
      }
      recognition.onerror = (e) => console.error('Recognition error', e)
      recognition.start()
      setIsRecording(true)
    } else {
      recognition.stop()
      setIsRecording(false)
    }
  }

  // Agora voice call wiring (simplified)
  const joinCall = async () => {
    try {
      const channelName = prompt('Enter channel name for call', 'demo-channel') || 'demo-channel'
      // Request token from server
      const tokenRes = await axios.post(`${SERVER_ORIGIN}/token`, { channelName })
      const { token, appID } = tokenRes.data

      // Attempt to dynamically import Agora RTC SDK
      const AgoraRTC = await import('agora-rtc-sdk-ng').then(m => m.default || m).catch(err => {
        console.warn('Agora SDK import failed', err)
        return null
      })

      if (!AgoraRTC) {
        alert('Agora SDK not installed. See README for instructions to npm install agora-rtc-sdk-ng in client.');
        return
      }

      const client = AgoraRTC.createClient({ mode: 'rtc', codec: 'vp8' })
      await client.join(appID, channelName, token, null)

      // create local audio track and publish
      const localAudioTrack = await AgoraRTC.createMicrophoneAudioTrack()
      await client.publish([localAudioTrack])
      mediaStreamRef.current = { client, localAudioTrack }

      client.on('user-published', async (user, mediaType) => {
        await client.subscribe(user, mediaType)
        if (mediaType === 'audio') {
          const remoteAudioTrack = user.audioTrack
          remoteAudioTrack.play()
        }
      })

      setInCall(true)
      setMuted(false)
    } catch (err) {
      console.error('joinCall error', err)
      alert('Could not join call: ' + (err.message || err))
    }
  }

  const leaveCall = async () => {
    try {
      const ms = mediaStreamRef.current
      if (ms && ms.localAudioTrack) {
        ms.localAudioTrack.stop()
        ms.localAudioTrack.close()
      }
      if (ms && ms.client) {
        await ms.client.leave()
      }
    } catch (err) {
      console.warn('leave call error', err)
    }
    mediaStreamRef.current = null
    setInCall(false)
  }

  const toggleMute = () => {
    const ms = mediaStreamRef.current
    if (!ms || !ms.localAudioTrack) return
    if (!muted) {
      ms.localAudioTrack.setEnabled(false)
      setMuted(true)
    } else {
      ms.localAudioTrack.setEnabled(true)
      setMuted(false)
    }
  }

  const handleImageUpload = (e) => {
    const file = e.target.files[0]
    if (!file) return
    
    const reader = new FileReader()
    reader.onload = (event) => {
      setUploadedImage(event.target.result)
      setMessages(prev => [...prev, { role: 'system', content: `📸 Image uploaded: ${file.name}` }])
    }
    reader.readAsDataURL(file)
  }

  const readPrescription = async () => {
    if (!uploadedImage) {
      setMessages(prev => [...prev, { role: 'system', content: '❌ No image uploaded yet' }])
      return
    }

    setMessages(prev => [...prev, { role: 'system', content: '🔍 Analyzing prescription...' }])

    try {
      const res = await axios.post(`${SERVER_ORIGIN}/prescription`, {
        sessionId,
        imageBase64: uploadedImage
      })

      const prescription = res.data.prescription
      let prescriptionText = '💊 PRESCRIPTION DETAILS\n'
      if (prescription.raw) {
        prescriptionText += prescription.raw
      } else {
        prescriptionText += `Patient: ${prescription.patientName}\nDate: ${prescription.date}\nDoctor: ${prescription.doctor}\n\nMedications:\n`
        if (prescription.medications && Array.isArray(prescription.medications)) {
          prescription.medications.forEach((med, i) => {
            prescriptionText += `\n${i + 1}. ${med.name}\n   Dosage: ${med.dosage}\n   Frequency: ${med.frequency}\n   Duration: ${med.duration}`
          })
        }
      }
      setMessages(prev => [...prev, { role: 'assistant', content: prescriptionText }])
    } catch (err) {
      setMessages(prev => [...prev, { role: 'assistant', content: '❌ Error reading prescription: ' + (err.message || err) }])
    }
  }

  return (
    <div className="chat-root">
      <div className="sidebar">
        <div style={{ marginBottom: '12px', paddingBottom: '8px', borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
          <label style={{ fontSize: '12px', color: '#93c5fd', textTransform: 'uppercase' }}>🔒 Backend Auth</label>
          <div style={{ display: 'flex', gap: '6px', marginTop: '8px' }}>
            <input value={authUser} onChange={(e)=>setAuthUser(e.target.value)} placeholder="user" style={{ padding: '6px', borderRadius: '6px', background: 'transparent', border: '1px solid rgba(255,255,255,0.06)', color: 'inherit', width: '80px' }} />
            <input value={authPass} onChange={(e)=>setAuthPass(e.target.value)} type="password" placeholder="pass" style={{ padding: '6px', borderRadius: '6px', background: 'transparent', border: '1px solid rgba(255,255,255,0.06)', color: 'inherit', width: '110px' }} />
          </div>
          <div style={{ fontSize: '11px', color: '#93c5fd', marginTop: '6px' }}>Credentials are stored only in-browser for this session.</div>
          <div style={{ marginTop: '8px', display: 'flex', gap: '8px', alignItems: 'center' }}>
            <button onClick={() => { sessionStorage.setItem('agora_auth_user', authUser); sessionStorage.setItem('agora_auth_pass', authPass); alert('Credentials saved to session.'); }} style={{ padding: '6px 8px', borderRadius: '6px', background: '#3b82f6', color: 'white', border: 'none' }}>Save</button>
            <button onClick={async () => {
              try {
                const res = await axios.get(`${SERVER_ORIGIN}/memories?sessionId=test`)
                alert('Auth test succeeded. Received ' + (res.data?.memories?.length ?? JSON.stringify(res.data)))
              } catch (e) {
                if (e.response && e.response.status === 401) alert('Unauthorized (401)')
                else alert('Auth test failed: ' + (e.message || e))
              }
            }} style={{ padding: '6px 8px', borderRadius: '6px', background: '#2dd4bf', color: '#042a2a', border: 'none' }}>Test Auth</button>
            <div style={{ fontSize: '12px', color: '#93c5fd' }}>Health: <span id="reactHealth">?</span></div>
          </div>
        </div>
        <div className="controls">
          <button onClick={joinCall} disabled={inCall}>Join Voice</button>
          <button onClick={leaveCall} disabled={!inCall}>End Call</button>
          <button onClick={toggleMute} disabled={!inCall}>{muted ? 'Unmute' : 'Mute'}</button>
          <button onClick={toggleRecording}>{isRecording ? 'Stop STT' : 'Speak (STT)'}</button>
        </div>
        <div style={{ marginTop: '12px', paddingTop: '12px', borderTop: '1px solid rgba(255,255,255,0.1)' }}>
          <label style={{ display: 'block', marginBottom: '8px', fontSize: '12px', color: '#93c5fd', textTransform: 'uppercase' }}>
            💊 Prescription
          </label>
          <input
            type="file"
            id="imageUpload"
            accept="image/*"
            onChange={handleImageUpload}
            style={{ display: 'block', fontSize: '11px', marginBottom: '8px' }}
          />
          <button onClick={readPrescription} style={{ width: '100%' }} disabled={!uploadedImage}>
            🔍 Read Prescription
          </button>
        </div>

        {/* NEW: Mood Display */}
        <div style={{ marginTop: '12px', paddingTop: '12px', borderTop: '1px solid rgba(255,255,255,0.1)' }}>
          <label style={{ display: 'block', marginBottom: '8px', fontSize: '12px', color: '#fbbf24', textTransform: 'uppercase' }}>
            😊 Current Mood
          </label>
          <div style={{
            background: 'rgba(251, 191, 36, 0.1)',
            border: '1px solid rgba(251, 191, 36, 0.3)',
            borderRadius: '6px',
            padding: '12px',
            textAlign: 'center',
            fontSize: '28px'
          }}>
            {currentMood === 'happy' && '😊'}
            {currentMood === 'sad' && '😢'}
            {currentMood === 'angry' && '😠'}
            {currentMood === 'excited' && '🚀'}
            {currentMood === 'anxious' && '😰'}
            {currentMood === 'loving' && '💕'}
            {currentMood === 'grateful' && '🙏'}
            {currentMood === 'surprised' && '😲'}
            {currentMood === 'confident' && '💪'}
            {currentMood === 'peaceful' && '🧘'}
            {(currentMood === 'neutral' || !currentMood) && '😐'}
          </div>
          <div style={{ color: '#d1d5db', textAlign: 'center', marginTop: '8px', fontSize: '13px' }}>
            {currentMood.charAt(0).toUpperCase() + currentMood.slice(1)}
          </div>
        </div>

        {/* NEW: Memory Panel */}
        <div style={{ marginTop: '12px', paddingTop: '12px', borderTop: '1px solid rgba(255,255,255,0.1)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
            <label style={{ fontSize: '12px', color: '#a78bfa', textTransform: 'uppercase' }}>
              📖 Memories ({memories.length})
            </label>
            <button
              onClick={() => setShowMemories(!showMemories)}
              style={{
                background: 'none',
                border: 'none',
                color: '#a78bfa',
                cursor: 'pointer',
                fontSize: '12px'
              }}
            >
              {showMemories ? '−' : '+'}
            </button>
          </div>
          {showMemories && (
            <div style={{
              maxHeight: '200px',
              overflowY: 'auto',
              background: 'rgba(167, 139, 250, 0.05)',
              border: '1px solid rgba(167, 139, 250, 0.2)',
              borderRadius: '6px',
              padding: '10px'
            }}>
              {memories.length === 0 ? (
                <div style={{ color: '#9ca3af', fontSize: '12px', fontStyle: 'italic' }}>
                  No memories yet. Chat about your feelings to create memories.
                </div>
              ) : (
                memories.map(mem => (
                  <div
                    key={mem.id}
                    style={{
                      background: mem.isFavorite ? 'rgba(255, 215, 0, 0.1)' : 'rgba(107, 114, 128, 0.1)',
                      border: mem.isFavorite ? '1px solid rgba(255, 215, 0, 0.3)' : '1px solid rgba(107, 114, 128, 0.2)',
                      borderRadius: '4px',
                      padding: '8px',
                      marginBottom: '6px',
                      fontSize: '11px',
                      color: '#d1d5db'
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '4px' }}>
                      <div>
                        <span style={{ color: '#fbbf24', marginRight: '4px' }}>
                          {mem.emotion === 'happy' && '😊'}
                          {mem.emotion === 'sad' && '😢'}
                          {mem.emotion === 'angry' && '😠'}
                          {mem.emotion === 'excited' && '🚀'}
                          {mem.emotion === 'anxious' && '😰'}
                          {mem.emotion === 'loving' && '💕'}
                          {mem.emotion === 'grateful' && '🙏'}
                          {mem.emotion === 'surprised' && '😲'}
                          {mem.emotion === 'confident' && '💪'}
                          {mem.emotion === 'peaceful' && '🧘'}
                          {!mem.emotion && '💭'}
                        </span>
                        <span style={{ wordBreak: 'break-word' }}>
                          {mem.content.substring(0, 40)}
                          {mem.content.length > 40 ? '...' : ''}
                        </span>
                      </div>
                      <div style={{ display: 'flex', gap: '4px' }}>
                        <button
                          onClick={() => toggleFavorite(mem.id)}
                          style={{
                            background: 'none',
                            border: 'none',
                            cursor: 'pointer',
                            fontSize: '12px',
                            padding: '0'
                          }}
                        >
                          {mem.isFavorite ? '⭐' : '☆'}
                        </button>
                        <button
                          onClick={() => deleteMemory(mem.id)}
                          style={{
                            background: 'none',
                            border: 'none',
                            color: '#ef4444',
                            cursor: 'pointer',
                            fontSize: '12px',
                            padding: '0'
                          }}
                        >
                          ✕
                        </button>
                        <button
                          onClick={async () => {
                            // If not yet stored as a full memory object (mock may return different shapes), ensure we have the memory
                            let memoryObj = mem
                            if (!mem.id && typeof mem === 'string') {
                              memoryObj = await saveMemory(mem, mem.emotion || 'neutral')
                            }
                            scheduleReminder(memoryObj)
                          }}
                          title="Set reminder"
                          style={{
                            background: 'none',
                            border: 'none',
                            color: '#60a5fa',
                            cursor: 'pointer',
                            fontSize: '12px',
                            padding: '0'
                          }}
                        >
                          ⏰
                        </button>
                        {reminders[mem.id] && (
                          <button
                            onClick={() => cancelReminder(mem.id)}
                            title="Cancel reminder"
                            style={{
                              background: 'none',
                              border: 'none',
                              color: '#f97316',
                              cursor: 'pointer',
                              fontSize: '12px',
                              padding: '0'
                            }}
                          >
                            ✖︎
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>

        <div className="session-id">Session: {sessionId}</div>
      </div>

      <div className="chat-panel">
        <div className="messages">
          {messages.map((m, i) => (
            <div key={i} className={`msg ${m.role}`}>
              <div className="role">
                {m.role}
                {/* NEW: Emotion badge for assistant messages */}
                {m.emotion && m.role === 'assistant' && (
                  <span style={{
                    marginLeft: '8px',
                    display: 'inline-block',
                    fontSize: '12px',
                    background: 'rgba(167, 139, 250, 0.2)',
                    border: '1px solid rgba(167, 139, 250, 0.5)',
                    borderRadius: '12px',
                    padding: '2px 8px',
                    color: '#c4b5fd'
                  }}>
                    {m.emotion === 'happy' && '😊 Happy'}
                    {m.emotion === 'sad' && '😢 Sad'}
                    {m.emotion === 'angry' && '😠 Angry'}
                    {m.emotion === 'excited' && '🚀 Excited'}
                    {m.emotion === 'anxious' && '😰 Anxious'}
                    {m.emotion === 'loving' && '💕 Loving'}
                    {m.emotion === 'grateful' && '🙏 Grateful'}
                    {m.emotion === 'surprised' && '😲 Surprised'}
                    {m.emotion === 'confident' && '💪 Confident'}
                    {m.emotion === 'peaceful' && '🧘 Peaceful'}
                  </span>
                )}
              </div>
              <div className="content">{m.content}</div>
            </div>
          ))}
        </div>

        <form className="composer" onSubmit={handleSend}>
          <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Type a message or press Speak" />
          <button type="submit">Send</button>
        </form>
      </div>
    </div>
  )
}
