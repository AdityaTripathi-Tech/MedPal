"""
Python Flask Backend for Emotional AI Chatbot
Advanced emotion detection using TextBlob, VADER, and custom keyword analysis
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import os
from dotenv import load_dotenv
from datetime import datetime
import json
import re
from collections import defaultdict

# NLP Libraries (lightweight approach)
from textblob import TextBlob

# Initialize Flask app
load_dotenv()
app = Flask(__name__)
CORS(app)

# Initialize NLP tools (VADER initialization moved to function to avoid startup delay)
sia = None

# In-memory storage
sessions = {}  # sessionId -> list of messages
memory_store = defaultdict(list)  # sessionId -> list of memories

# ========== ADVANCED EMOTION DETECTION SYSTEM ==========

EMOTION_KEYWORDS = {
    'happy': [
        'happy', 'glad', 'joyful', 'delighted', 'pleased', 'wonderful', 'great',
        'awesome', 'amazing', 'fantastic', 'excellent', 'love', 'enjoy', 'beautiful',
        'perfect', 'brilliant', 'superb', 'outstanding', 'terrific', 'thrilled'
    ],
    'sad': [
        'sad', 'unhappy', 'depressed', 'lonely', 'heartbroken', 'miserable',
        'down', 'upset', 'devastated', 'sorry', 'grief', 'loss', 'hurt',
        'struggling', 'crying', 'tears', 'blue', 'gloomy', 'melancholy'
    ],
    'angry': [
        'angry', 'furious', 'mad', 'frustrated', 'hate', 'irritated', 'annoyed',
        'outraged', 'fuming', 'livid', 'rage', 'upset', 'hostile', 'bitter',
        'resent', 'aggressive', 'damn', 'crap', 'pissed'
    ],
    'excited': [
        'excited', 'thrilled', 'pumped', "can't wait", 'amazing', 'fantastic',
        'incredible', 'wonderful', 'enthusiastic', 'energetic', 'anticipation',
        'looking forward', 'awesome', 'brilliant', 'eager', 'keen', 'ecstatic'
    ],
    'anxious': [
        'worried', 'nervous', 'scared', 'stressed', 'panic', 'overwhelmed',
        'anxious', 'concerned', 'frightened', 'uneasy', 'terrified', 'dread',
        'apprehensive', 'tense', 'afraid', 'anxious', 'nervous', 'worried'
    ],
    'loving': [
        'love', 'adore', 'cherish', 'caring', 'compassion', 'tender', 'affectionate',
        'romantic', 'passionate', 'devoted', 'intimate', 'warm', 'gentle'
    ],
    'grateful': [
        'grateful', 'thankful', 'appreciate', 'blessed', 'gratitude', 'thanks',
        'appreciate', 'lucky', 'fortunate', 'blessed', 'thankful'
    ],
    'surprised': [
        'surprised', 'shocked', 'astonished', 'amazed', 'unexpected', 'wow',
        'wow', 'incredible', 'unbelievable', 'shocking', 'startled'
    ],
    'confident': [
        'confident', 'proud', 'strong', 'capable', 'powerful', 'determined',
        'brave', 'courageous', 'believe', 'succeed', 'victory', 'triumph'
    ],
    'peaceful': [
        'peaceful', 'calm', 'relaxed', 'serene', 'tranquil', 'quiet', 'meditative',
        'content', 'satisfied', 'at ease', 'comfortable', 'rest'
    ]
}

EMOTION_INTENSIFIERS = ['very', 'so', 'really', 'extremely', 'absolutely', 'incredibly', 'totally']
EMOTION_NEGATORS = ["don't", "didn't", "no", "not", "never", "isn't", "doesn't"]

def detect_emotion_advanced(text):
    """
    Advanced emotion detection using multiple NLP techniques:
    1. Keyword matching (10 emotion types)
    2. Sentiment analysis (TextBlob)
    3. VADER sentiment intensity
    4. Negation handling
    5. Intensity detection
    """
    
    if not text or len(text.strip()) == 0:
        return {'emotion': 'neutral', 'confidence': 0.0, 'intensity': 'low', 'details': {}}
    
    lower_text = text.lower()
    detected_emotions = defaultdict(float)
    
    # 1. Keyword-based detection with intensity
    for emotion, keywords in EMOTION_KEYWORDS.items():
        for keyword in keywords:
            if keyword in lower_text:
                # Base score
                score = 1.0
                
                # Boost if intensifier is nearby
                for intensifier in EMOTION_INTENSIFIERS:
                    if f"{intensifier} {keyword}" in lower_text:
                        score = 2.0
                        break
                
                # Check for negation
                words = lower_text.split()
                keyword_idx = -1
                for i, w in enumerate(words):
                    if keyword in w:
                        keyword_idx = i
                        break
                
                if keyword_idx > 0 and any(neg in words[max(0, keyword_idx-2):keyword_idx] for neg in EMOTION_NEGATORS):
                    score *= 0.3  # Reduce confidence if negated
                
                detected_emotions[emotion] += score
    
    # 2. TextBlob sentiment analysis
    blob = TextBlob(text)
    polarity = blob.sentiment.polarity  # -1 to 1
    subjectivity = blob.sentiment.subjectivity  # 0 to 1
    
    # Map polarity to emotions
    if polarity > 0.6:
        detected_emotions['happy'] += 1.5
        detected_emotions['excited'] += 1.0
    elif polarity > 0.3:
        detected_emotions['peaceful'] += 1.0
        detected_emotions['grateful'] += 0.8
    elif polarity < -0.6:
        detected_emotions['sad'] += 1.5
        detected_emotions['angry'] += 1.2
    elif polarity < -0.3:
        detected_emotions['anxious'] += 1.0
        detected_emotions['worried'] += 0.8
    
    # 3. VADER sentiment analysis (more nuanced)
    vader_scores = sia.polarity_scores(text)
    compound = vader_scores['compound']  # -1 to 1
    
    if compound > 0.7:
        detected_emotions['excited'] += 1.5
    elif compound > 0.3:
        detected_emotions['happy'] += 1.2
    elif compound < -0.7:
        detected_emotions['angry'] += 1.5
    elif compound < -0.3:
        detected_emotions['sad'] += 1.2
    
    # Normalize and find top emotion
    if not detected_emotions:
        return {'emotion': 'neutral', 'confidence': 0.0, 'intensity': 'low', 'details': {}}
    
    # Calculate confidence (max score / sum of all scores)
    total_score = sum(detected_emotions.values())
    max_emotion = max(detected_emotions, key=detected_emotions.get)
    max_score = detected_emotions[max_emotion]
    confidence = max_score / total_score if total_score > 0 else 0.0
    
    # Determine intensity
    if max_score > 4.0:
        intensity = 'very high'
    elif max_score > 2.5:
        intensity = 'high'
    elif max_score > 1.5:
        intensity = 'medium'
    elif max_score > 0.5:
        intensity = 'low'
    else:
        intensity = 'very low'
    
    return {
        'emotion': max_emotion,
        'confidence': round(confidence, 2),
        'intensity': intensity,
        'score': round(max_score, 2),
        'polarity': round(polarity, 2),
        'vader_compound': round(compound, 2),
        'details': {k: round(v, 2) for k, v in detected_emotions.items() if v > 0.5}
    }

# ========== EMPATHY RESPONSE SYSTEM ==========

EMPATHY_RESPONSES = {
    'happy': [
        "💙 Your joy is contagious! I'm happy for you!",
        "🌟 That sounds wonderful! I can feel your positive energy!",
        "😊 Your happiness brings light to our conversation!",
    ],
    'sad': [
        "💙 I can hear you're going through something difficult. I'm here to listen and support you.",
        "💙 Your feelings are valid. Let's talk about what's troubling you.",
        "🤝 I'm here for you. Sometimes just talking helps.",
    ],
    'angry': [
        "🤝 I understand your frustration. Let's work through this together.",
        "💪 Your feelings are valid. It's okay to be upset.",
        "🛡️ I'm here to help you process these strong emotions.",
    ],
    'excited': [
        "🚀 Your enthusiasm is inspiring! Tell me more!",
        "🎉 I love your excitement! This sounds amazing!",
        "⚡ Your energy is electric! Let's dive into this!",
    ],
    'anxious': [
        "🤝 Let's calm down together. You're going to be okay.",
        "💙 I understand you're worried. Let's break this down step by step.",
        "🌿 Take a deep breath. I'm here to help you work through this.",
    ],
    'loving': [
        "💕 That's beautiful. Love and compassion are precious.",
        "🌹 What a tender moment. Thank you for sharing this.",
        "💖 Your warmth is felt. This is lovely.",
    ],
    'grateful': [
        "🙏 Gratitude is wonderful. Thank you for sharing this positive energy!",
        "✨ Your appreciation is beautiful. Gratitude multiplies joy!",
        "🌟 It's wonderful to share in your thankfulness.",
    ],
    'surprised': [
        "😲 Wow! That's quite unexpected! Tell me more!",
        "🌟 Interesting! Life has surprising moments, doesn't it?",
        "🎯 That's fascinating! What happened next?",
    ],
    'confident': [
        "💪 That confidence is inspiring! You've got this!",
        "⭐ Your strength shines through. Keep that energy!",
        "🏆 I love your determination and self-belief!",
    ],
    'peaceful': [
        "🌿 What a serene moment. Peace is precious.",
        "☮️ Your calm is contagious. I'm feeling it too.",
        "🧘 There's beauty in this stillness.",
    ]
}

def get_empathy_response(emotion):
    """Get a random empathetic response for an emotion"""
    if emotion in EMPATHY_RESPONSES:
        responses = EMPATHY_RESPONSES[emotion]
        import random
        return random.choice(responses)
    return "I'm here to listen and support you."

# ========== API ENDPOINTS ==========

@app.route('/chat', methods=['POST'])
def chat():
    """Chat endpoint with advanced emotion detection"""
    try:
        data = request.json
        session_id = data.get('sessionId', 'default')
        message = data.get('message', '')
        
        if not message:
            return jsonify({'error': 'message required'}), 400
        
        # Detect emotion using advanced system
        emotion_analysis = detect_emotion_advanced(message)
        
        # Get empathy response
        empathy_msg = get_empathy_response(emotion_analysis['emotion'])
        
        # Mock AI response (in production, call OpenAI)
        ai_reply = f"{empathy_msg}\n\n[Response to your message would go here]"
        
        return jsonify({
            'reply': ai_reply,
            'emotion': emotion_analysis['emotion'],
            'confidence': emotion_analysis['confidence'],
            'intensity': emotion_analysis['intensity'],
            'analysis': emotion_analysis
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/memory', methods=['POST'])
def save_memory():
    """Save a memory with emotion tag"""
    try:
        data = request.json
        session_id = data.get('sessionId', 'default')
        content = data.get('content', '')
        emotion = data.get('emotion')
        
        if not content:
            return jsonify({'error': 'content required'}), 400
        
        # Auto-detect emotion if not provided
        if not emotion:
            emotion_analysis = detect_emotion_advanced(content)
            emotion = emotion_analysis['emotion']
        
        memory = {
            'id': int(datetime.now().timestamp() * 1000),
            'sessionId': session_id,
            'content': content,
            'emotion': emotion,
            'timestamp': datetime.now().isoformat(),
            'isFavorite': False
        }
        
        memory_store[session_id].append(memory)
        
        return jsonify(memory)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/memories/<session_id>', methods=['GET'])
def get_memories(session_id):
    """Get all memories for a session"""
    try:
        memories = memory_store.get(session_id, [])
        return jsonify(memories)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/memory/<int:memory_id>/favorite', methods=['PUT'])
def toggle_favorite(memory_id):
    """Toggle favorite status of a memory"""
    try:
        data = request.json
        session_id = data.get('sessionId', 'default')
        
        memories = memory_store.get(session_id, [])
        for memory in memories:
            if memory['id'] == memory_id:
                memory['isFavorite'] = not memory['isFavorite']
                return jsonify(memory)
        
        return jsonify({'error': 'Memory not found'}), 404
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/memory/<int:memory_id>', methods=['DELETE'])
def delete_memory(memory_id):
    """Delete a memory"""
    try:
        data = request.json
        session_id = data.get('sessionId', 'default')
        
        memories = memory_store.get(session_id, [])
        for i, memory in enumerate(memories):
            if memory['id'] == memory_id:
                deleted = memories.pop(i)
                return jsonify({'success': True, 'deleted': deleted})
        
        return jsonify({'error': 'Memory not found'}), 404
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/emotions-test', methods=['POST'])
def emotions_test():
    """Test emotion detection with various inputs"""
    try:
        data = request.json
        test_texts = data.get('texts', [])
        
        results = []
        for text in test_texts:
            analysis = detect_emotion_advanced(text)
            results.append({
                'text': text,
                'analysis': analysis
            })
        
        return jsonify({'results': results})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({'status': 'healthy', 'service': 'Emotional AI Backend'})

# ========== MAIN ==========

if __name__ == '__main__':
    port = int(os.getenv('PORT', 5000))
    app.run(debug=True, host='0.0.0.0', port=port)
