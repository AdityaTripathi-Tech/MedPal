import React from 'react'
import ChatWindow from './components/ChatWindow'

export default function App() {
  return (
    <div className="app-root">
      <header className="app-header">
        <h1>Agora Conversational AI</h1>
      </header>
      <main>
        <ChatWindow />
      </main>
    </div>
  )
}
