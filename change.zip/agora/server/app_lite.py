"""
Python Flask Backend for Emotional AI Chatbot - LIGHTWEIGHT VERSION
Emotion detection using TextBlob only (no heavy NLTK)
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import os
from dotenv import load_dotenv
from datetime import datetime
from collections import defaultdict
from textblob import TextBlob
import base64
import functools

# Initialize Flask app
load_dotenv()
app = Flask(__name__)
CORS(app)

# Load optional protection credentials from environment
PROTECT_USER = os.getenv('PROTECT_USER')
PROTECT_PASS = os.getenv('PROTECT_PASS')

def _unauthorized():
    return (jsonify({'success': False, 'error': 'Unauthorized'}), 401, {'WWW-Authenticate': 'Basic realm="Login Required"'})

def check_basic_auth(auth_header: str) -> bool:
    if not auth_header:
        return False
    try:
        scheme, _, token = auth_header.partition(' ')
        if scheme.lower() != 'basic':
            return False
        decoded = base64.b64decode(token).decode('utf-8')
        user, _, pwd = decoded.partition(':')
        return PROTECT_USER and PROTECT_PASS and user == PROTECT_USER and pwd == PROTECT_PASS
    except Exception:
        return False

def requires_auth(f):
    @functools.wraps(f)
    def wrapped(*args, **kwargs):
        # If protection not configured, allow
        if not PROTECT_USER or not PROTECT_PASS:
            return f(*args, **kwargs)
        auth_header = request.headers.get('Authorization')
        if not check_basic_auth(auth_header):
            return _unauthorized()
        return f(*args, **kwargs)
    return wrapped

# In-memory storage
memory_store = defaultdict(list)  # sessionId -> list of memories

# ========== EMOTION DETECTION SYSTEM ==========

EMOTION_KEYWORDS = {
    'happy': [
        'happy', 'glad', 'joyful', 'delighted', 'pleased', 'wonderful', 'great',
        'awesome', 'amazing', 'fantastic', 'excellent', 'love', 'enjoy', 'beautiful',
        'perfect', 'brilliant', 'superb', 'outstanding', 'terrific', 'thrilled'
    ],
    'sad': [
        'sad', 'unhappy', 'depressed', 'lonely', 'heartbroken', 'miserable',
        'down', 'upset', 'devastated', 'sorry', 'grief', 'loss', 'hurt',
        'struggling', 'crying', 'tears', 'blue', 'gloomy', 'melancholy'
    ],
    'angry': [
        'angry', 'furious', 'mad', 'rage', 'hate', 'annoyed', 'irritated',
        'frustrated', 'upset', 'aggressive', 'hostile', 'bitter', 'resentful',
        'outraged', 'livid', 'seething'
    ],
    'excited': [
        'excited', 'thrilled', 'pumped', 'energetic', 'enthusiastic', 'eager',
        'looking forward', 'can\'t wait', 'amazing', 'fantastic', 'incredible',
        'awesome', 'great', 'wonderful'
    ],
    'anxious': [
        'anxious', 'nervous', 'worried', 'concerned', 'frightened', 'uneasy',
        'terrified', 'dread', 'apprehensive', 'tense', 'afraid', 'panic'
    ],
    'loving': [
        'love', 'adore', 'cherish', 'caring', 'compassion', 'tender', 'affectionate',
        'romantic', 'passionate', 'devoted', 'intimate', 'warm', 'gentle'
    ],
    'grateful': [
        'grateful', 'thankful', 'appreciate', 'blessed', 'gratitude', 'thanks',
        'lucky', 'fortunate', 'blessed'
    ],
    'surprised': [
        'surprised', 'shocked', 'astonished', 'amazed', 'unexpected', 'wow',
        'incredible', 'unbelievable', 'shocking', 'startled'
    ],
    'confident': [
        'confident', 'proud', 'strong', 'capable', 'powerful', 'determined',
        'brave', 'courageous', 'succeed', 'victory', 'triumph'
    ],
    'peaceful': [
        'peaceful', 'calm', 'relaxed', 'serene', 'tranquil', 'quiet', 'content',
        'satisfied', 'comfortable'
    ]
}

EMOTION_INTENSIFIERS = ['very', 'so', 'really', 'extremely', 'absolutely', 'incredibly', 'totally']
EMOTION_NEGATORS = ["don't", "didn't", "no", "not", "never", "isn't", "doesn't"]

EMPATHY_RESPONSES = {
    'happy': [
        "That's wonderful! 🌟 I'm glad you're feeling so positive!",
        "That sounds amazing! Your happiness is contagious! ✨",
        "I love the energy! Keep that joy going! 🎉",
        "That's fantastic! Enjoy this beautiful moment! 💫",
        "You deserve to feel this happy! 🌈"
    ],
    'sad': [
        "I hear you, and I'm sorry you're feeling this way. 💙 Things will improve.",
        "It's okay to feel sad sometimes. I'm here to listen. 🤝",
        "Your feelings are valid. Would you like to talk about it? 💔",
        "I understand. Sometimes we all have difficult moments. 🌧️",
        "You're not alone in this. Let's get through it together. 💪"
    ],
    'angry': [
        "I sense your frustration. It's okay to feel angry. Let's talk it through. 🔥",
        "Your feelings matter. Take a breath - I'm here to help. 💨",
        "I understand why you're upset. What happened? Let's work through it. 🎯",
        "It's natural to feel frustrated. How can I help? 🤝",
        "I hear the intensity. Let's find a way to address this. ⚡"
    ],
    'excited': [
        "That's amazing! Your excitement is inspiring! 🚀",
        "Wow, that's awesome! Tell me more! 🎉",
        "I can feel your energy! That's fantastic! ⚡",
        "This sounds incredible! Go for it! 🌟",
        "Your enthusiasm is contagious! I love it! 💥"
    ],
    'anxious': [
        "I understand you're worried. It's okay to feel this way. Let's talk. 💙",
        "Anxiety is temporary. You're going to get through this. 🌈",
        "Your concerns are valid. Want to break it down together? 🤝",
        "Take a breath. I'm here with you. You've got this. 💪",
        "It's okay to feel nervous. One step at a time. 🌿"
    ],
    'loving': [
        "That's beautiful! Love makes everything special. ❤️",
        "What a wonderful feeling! Cherish it. 💕",
        "That's so sweet! Your compassion shines through. 🌹",
        "Love is the most powerful emotion. Keep spreading it! 💗",
        "That's heartwarming! You have a beautiful soul. ✨"
    ],
    'grateful': [
        "Gratitude is beautiful! You have a wonderful perspective. 🙏",
        "That's amazing! Appreciation brings more blessings. 🌟",
        "I love your gratitude! It's inspiring. 💖",
        "You have a grateful heart! That's beautiful. 🌈",
        "Thankfulness is powerful! Keep that energy! ✨"
    ],
    'surprised': [
        "Wow, that's unexpected! How interesting! 😲",
        "That's quite a surprise! Tell me more! 🤔",
        "Surprising moments can be the best! 🎊",
        "Life is full of surprises! This sounds fascinating! 🌟",
        "I'm intrigued! What happened? 👀"
    ],
    'confident': [
        "That's amazing confidence! You've got this! 💪",
        "Your self-assurance is powerful! Keep going! 🚀",
        "I love that confidence! You can achieve anything! 🌟",
        "Your strength shines through! Believe in yourself! ⚡",
        "That's the spirit! Keep that confidence! 🏆"
    ],
    'peaceful': [
        "That's beautiful peace. Embrace it. 🕉️",
        "A calm mind is a powerful mind. 🧘",
        "I love your serene energy. 🌿",
        "Peace is precious. You're in a good place. ☮️",
        "That's wonderful tranquility. Enjoy this moment. 🌅"
    ]
}

def detect_emotion_simple(text):
    """
    Simple emotion detection using TextBlob + keyword matching
    """
    if not text or len(text.strip()) == 0:
        return {'emotion': 'neutral', 'confidence': 0.0, 'intensity': 'low', 'polarity': 0}
    
    lower_text = text.lower()
    detected_emotions = defaultdict(float)
    
    # 1. Keyword-based detection with intensity
    for emotion, keywords in EMOTION_KEYWORDS.items():
        for keyword in keywords:
            if keyword in lower_text:
                score = 1.0
                
                # Boost if intensifier is nearby
                for intensifier in EMOTION_INTENSIFIERS:
                    if f"{intensifier} {keyword}" in lower_text:
                        score = 2.0
                        break
                
                detected_emotions[emotion] += score
    
    # 2. TextBlob sentiment analysis
    blob = TextBlob(text)
    polarity = blob.sentiment.polarity  # -1 to 1
    
    # Map polarity to emotions
    if polarity > 0.6:
        detected_emotions['happy'] += 1.5
        detected_emotions['excited'] += 1.0
    elif polarity > 0.3:
        detected_emotions['peaceful'] += 1.0
        detected_emotions['grateful'] += 0.8
    elif polarity < -0.6:
        detected_emotions['sad'] += 1.5
        detected_emotions['angry'] += 1.2
    elif polarity < -0.3:
        detected_emotions['anxious'] += 1.0
    
    # Determine primary emotion
    if detected_emotions:
        primary_emotion = max(detected_emotions, key=detected_emotions.get)
        confidence = min(1.0, detected_emotions[primary_emotion] / 5.0)
    else:
        primary_emotion = 'neutral'
        confidence = 0.0
    
    # Intensity mapping
    if confidence > 0.7:
        intensity = 'high'
    elif confidence > 0.4:
        intensity = 'medium'
    else:
        intensity = 'low'
    
    return {
        'emotion': primary_emotion,
        'confidence': round(confidence, 2),
        'intensity': intensity,
        'polarity': round(polarity, 2),
        'detected_emotions': dict(detected_emotions)
    }

def get_empathy_response(emotion):
    """Get an empathetic response for the emotion"""
    responses = EMPATHY_RESPONSES.get(emotion, EMPATHY_RESPONSES['neutral'] if 'neutral' in EMPATHY_RESPONSES else ["I understand. Tell me more. 💙"])
    import random
    return random.choice(responses) if responses else "I'm here to listen. 💙"

# ========== API ENDPOINTS ==========

@app.route('/chat', methods=['POST'])
@requires_auth
def chat():
    """Main chat endpoint"""
    try:
        data = request.json
        session_id = data.get('sessionId', 'default')
        message = data.get('message', '')
        
        # Detect emotion
        emotion_analysis = detect_emotion_simple(message)
        empathy_msg = get_empathy_response(emotion_analysis['emotion'])
        
        return jsonify({
            'success': True,
            'reply': empathy_msg,
            'emotion': emotion_analysis['emotion'],
            'confidence': emotion_analysis['confidence'],
            'intensity': emotion_analysis['intensity'],
            'polarity': emotion_analysis['polarity'],
            'analysis': emotion_analysis
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/memory', methods=['POST'])
@requires_auth
def save_memory():
    """Save a memory"""
    try:
        data = request.json
        session_id = data.get('sessionId', 'default')
        message = data.get('message', '')
        emotion = data.get('emotion', 'neutral')
        
        memory = {
            'id': len(memory_store[session_id]) + 1,
            'message': message,
            'emotion': emotion,
            'timestamp': datetime.now().isoformat(),
            'favorite': False
        }
        
        memory_store[session_id].append(memory)
        
        return jsonify({
            'success': True,
            'memory': memory,
            'total_memories': len(memory_store[session_id])
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/memories', methods=['GET'])
@requires_auth
def get_memories():
    """Get all memories for a session"""
    try:
        session_id = request.args.get('sessionId', 'default')
        memories = memory_store.get(session_id, [])
        
        return jsonify({
            'success': True,
            'memories': memories,
            'total': len(memories)
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/memory/<int:memory_id>/favorite', methods=['PUT'])
@requires_auth
def toggle_favorite(memory_id):
    """Toggle favorite status on a memory"""
    try:
        data = request.json
        session_id = data.get('sessionId', 'default')
        
        for memory in memory_store[session_id]:
            if memory['id'] == memory_id:
                memory['favorite'] = not memory['favorite']
                return jsonify({'success': True, 'memory': memory})
        
        return jsonify({'success': False, 'error': 'Memory not found'}), 404
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/memory/<int:memory_id>', methods=['DELETE'])
@requires_auth
def delete_memory(memory_id):
    """Delete a memory"""
    try:
        data = request.json
        session_id = data.get('sessionId', 'default')
        
        memory_store[session_id] = [m for m in memory_store[session_id] if m['id'] != memory_id]
        
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'service': 'Emotional AI Backend (Lightweight)',
        'version': '1.0'
    })

# ========== MAIN ==========

if __name__ == '__main__':
    port = int(os.getenv('PORT', 5000))
    print(f"🚀 Starting Emotional AI Chatbot Backend on port {port}...")
    app.run(debug=False, host='127.0.0.1', port=port, use_reloader=False)
